package com.example.lab4_footballcompetitions;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    private ListView list;
    private RequestQueue Queue;
    private Context mCtx;

    private ListView mListView;
    private ArrayAdapter aAdapter;
    Button button;
    String TAG="HUOMIO";

    int counter=0;

    int id3;
    String id2;
    String name;
    String countrycode;
    String ensignUrl;
    String parentArea;

    ArrayList<String> Areas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Queue = Volley.newRequestQueue(this);
        list = (ListView)findViewById(R.id.Areaslist);

        mCtx = this;

        Log.d(TAG, "onCreate: LoadFromWeb()");

        LoadFromWeb();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run()
            {
                Updatelistview();
            }
        }, 500);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Log.d(TAG, "onItemClick: !!!!!!!!!!!!!!!!!!seuraava nakyma");
                Intent intent = new Intent();
                intent.setClass(mCtx, Main2Activity.class);
                intent.putExtra("MESSAGE1", id);
                //intent.putExtra("MESSAGE2", id2);
                startActivity(intent);
            }
        });

    }


    @Override
    public void onClick(View v)
    {

    }

private void LoadFromWeb()
        {
        String url = "http://api.football-data.org/v2/areas";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
        new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("areas");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject o = jsonArray.getJSONObject(i);

                                id3 = o.getInt("id");

                                id2= String.valueOf(id3);
                                name = o.getString("name");
                                countrycode = o.getString("countryCode");
                                parentArea = o.getString("parentArea");

                                String o2= id2 + " , " + name + " , " + countrycode + " , " +parentArea;

                                Areas.add(o2);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        Queue.add(request);

        }

    private void Updatelistview()
    {
        aAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,Areas);
        list.setAdapter(aAdapter);
    }

}


