package com.example.lab4_footballcompetitions;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Main2Activity extends AppCompatActivity
{
    Long id2;
    String id3;
    String TAG = "!!!!!!!!!!";
    private RequestQueue Queue;
    TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Queue = Volley.newRequestQueue(this);
        textview = (TextView) findViewById(R.id.textview);
        textview.setMovementMethod(new ScrollingMovementMethod());

        Log.d(TAG, "onCreate: Tervetuloa!!!");

        if (getIntent() != null) {
            id2 = getIntent().getLongExtra("MESSAGE1", 0);
        }
        long id = 2000 + id2;
        id3 = String.valueOf(id);

        Log.d(TAG, "onCreate:"+id3);

        LoadFromWeb();
    }


    private void LoadFromWeb() {
        String url = "http://api.football-data.org/v2/competitions?areas=" + id3;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("competitions");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = jsonArray.getJSONObject(i);

                                int id = o.getInt("id");

                                JSONObject area = o.getJSONObject("area");
                                int id2 = area.getInt("id");
                                String name = area.getString("name");
                                String countrycode = area.getString("countryCode");
                                String ensignUrl = area.getString("ensignUrl");

                                String name2 = o.getString("name");
                                String code = o.getString("code");
                                String emblemUrl = o.getString("emblemUrl");
                                String plan = o.getString("plan");

                                JSONObject currentSeason = o.getJSONObject("currentSeason");
                                int id3 = currentSeason.getInt("id");
                                String startDate = currentSeason.getString("startDate");
                                String endDate = currentSeason.getString("endDate");
                                String currentMatchDay = currentSeason.getString("currentMatchday");
                                String winner = currentSeason.getString("winner");

                                int numberOfAvailableSeasons = o.getInt("numberOfAvailableSeasons");
                                String lastUpdated = o.getString("lastUpdated");

                                textview.append(id + "\n" + name2 + "\n" + code + "\n" + emblemUrl + "\n"
                                        + plan + "\n" + numberOfAvailableSeasons + "\n" + lastUpdated + " \nArea: \n"
                                        + id2 + "\n" + name + "\n" + countrycode + "\n" + ensignUrl + "\nCurrent Season:\n"
                                        + id3 + "\n" + startDate + "\n" + endDate + "\n" + currentMatchDay + "\n" + winner + "\n\n");

                                Log.d(TAG, "onResponse: " + id + "\n" + name2 + "\n" + code + "\n" + emblemUrl + "\n"
                                        + plan + "\n" + numberOfAvailableSeasons + "\n" + lastUpdated + " \nArea: \n"
                                        + id2 + "\n" + name + "\n" + countrycode + "\n" + ensignUrl + "\nCurrent Season:\n"
                                        + id3 + "\n" + startDate + "\n" + endDate + "\n" + currentMatchDay + "\n" + winner + "\n\n");
                            }
                            } catch(JSONException e){
                                e.printStackTrace();
                            }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        Queue.add(request);
    }
}


