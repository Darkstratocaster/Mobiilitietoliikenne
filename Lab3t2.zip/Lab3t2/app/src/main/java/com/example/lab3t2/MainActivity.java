package com.example.lab3t2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private TextView mTextViewResult;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewResult = findViewById(R.id.text_view_result);

        mQueue = Volley.newRequestQueue(this);

        Button buttonParse = findViewById(R.id.button_parse);

        mQueue = Volley.newRequestQueue(this);
        mTextViewResult.setMovementMethod(new ScrollingMovementMethod());

        /*buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonParse();
            }
        });*/

        jsonParse();


    }

    private void jsonParse() {

        String url = "https://api.football-data.org/v2/competitions?areas=2072";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            //JSONArray jsonArrayalku = response.getJSONArray("areas")

                            JSONArray jsonArray = response.getJSONArray("competitions");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = jsonArray.getJSONObject(i);

                                int id = o.getInt("id");

                                JSONObject area = o.getJSONObject("area");
                                int id2 = area.getInt("id");
                                String name = area.getString("name");
                                String countrycode = area.getString("countryCode");
                                String ensignUrl = area.getString("ensignUrl");

                                String name2 = o.getString("name");
                                String code = o.getString("code");
                                String emblemUrl = o.getString("emblemUrl");
                                String plan = o.getString("plan");

                                JSONObject currentSeason = o.getJSONObject("currentSeason");
                                int id3 = currentSeason.getInt("id");
                                String startDate = currentSeason.getString("startDate");
                                String endDate = currentSeason.getString("endDate");
                                String currentMatchDay = currentSeason.getString("currentMatchday");
                                String winner = currentSeason.getString("winner");

                                int numberOfAvailableSeasons = o.getInt("numberOfAvailableSeasons");
                                String lastUpdated = o.getString("lastUpdated");


                                mTextViewResult.append(id + "\nNimi: "  + name2 + "\nKoodi: " + code + "\nNettiosoite: " + emblemUrl + "\nSuunnitelma: "
                                        + plan + "\nKausia saatavilla: " + numberOfAvailableSeasons + "\nP'ivitetty viimeksi: " + lastUpdated + " \nAlue: \n"
                                        + id2  + "\nAlueen nimi: " + name + "\nValtiokoodi: " + countrycode + "\nNettiosoite: " + ensignUrl + "\nNykyinen kausi:\n"
                                        + id3 + "\nAloituspäivä: " + startDate + "\nLoppupäivä: " + endDate + "\nTämänhetkinen ottelupäivä: " +currentMatchDay + "\nVoittaja: " + winner + "\n\n");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);
    }
}