package com.example.lab1_t12;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private FusedLocationProviderClient client;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_LOCATION = 12345;

    Geocoder geocoder;
    List<Address> location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        client = LocationServices.getFusedLocationProviderClient(this);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION))
            {
            }
            else
            {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_ACCESS_LOCATION);
            }
            GPSintent(null);
        }
        else
        {
            GPSintent(null);
        }
    }

    public void getLocation(Double latitude, Double longitude)
    {
        geocoder = new Geocoder(this, Locale.getDefault());

        try {
            location = geocoder.getFromLocation(latitude, longitude, 1);
            String locality = location.get(0).getLocality();
            String country = location.get(0).getCountryName();

            TextView textView1 = findViewById(R.id.locationText1);
            TextView textView2 = findViewById(R.id.locationText2);

            textView1.setText("" + String.format("%.1f", latitude) + ", " + String.format("%.1f", longitude) + "\r\n");
            textView2.setText("" + locality + "\n" + country + "\r\n");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        GPSintent(null);
    }

    public void GPSintent(View v){
        client.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            Double latitude = location.getLatitude();
                            Double longitude = location.getLongitude();
                            getLocation(latitude, longitude);
                        }
                        else{
                        }
                    }
                });
    }
}
